<?php

function schedule_import_accounts_and_users(){
    $account_ids = \DB::connection('pbx')->table('v_domains')->pluck('account_id')->unique()->filter()->toArray();
    $partner_ids = \DB::connection('pbx')->table('v_domains')->pluck('partner_id')->unique()->filter()->toArray();
    
    $customer_ids = array_merge($account_ids,$partner_ids);
   
    $accounts = \DB::connection('ct_erp')->table('crm_accounts')->whereIn('id',$customer_ids)->get();
    foreach($accounts as $account){
        $data = (array) $account;
        \DB::connection('pbx_erp')->table('crm_accounts')->updateOrInsert(['id'=>$account->id],$data);
    }
    \DB::connection('pbx_erp')->table('crm_accounts')->whereNotIn('id',$customer_ids)->update(['status' => 'Deleted','is_deleted' => 1, 'deleted_at' => date('Y-m-d H:i:s')]);
    
    $users =  \DB::connection('ct_erp')->table('erp_users')->whereIn('account_id',$customer_ids)->get();
    $user_ids = $users->pluck('id')->toArray();
    
    foreach($users as $user){
        $data = (array) $user;
        \DB::connection('pbx_erp')->table('erp_users')->updateOrInsert(['id'=>$user->id],$data);
    }
    \DB::connection('pbx_erp')->table('erp_users')->where('account_id','>',0)->whereNotIn('id',$user_ids)->update(['active' => 0,'is_deleted' => 1, 'updated_at' => date('Y-m-d H:i:s')]);
}