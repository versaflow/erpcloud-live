<?php

function fusionpbx_edit_curl($url, $query_id, $post_data, $unset_id = false){
   
    if($unset_id){
        unset($post_data['id']);
    }
    
    $client = new GuzzleHttp\Client();
   // dd($URI);
    $params['headers'] = ['erp_aftersave'=>1];
    
    if(!empty($post_data['domain_uuid'])){
        $pbx_row = \DB::connection('pbx')->table('v_users as vu')
        ->join('v_domains as vd', 'vd.domain_uuid', '=', 'vu.domain_uuid')
        ->where('vd.domain_uuid', $post_data['domain_uuid'])
        ->get()->first();
        $domain_name = \DB::connection('pbx')->table('v_domains')->where('domain_uuid', $post_data['domain_uuid'])->pluck('domain_name')->first();
        $url = str_replace('156.0.96.60',$domain_name,$url);
        $key = $pbx_row->api_key;
    }else{
        $key = 'e2e4e9a0-c678-45a2-97a2-e24f9f2481fa';
    }
    
    $params['query'] = ['id'=>$query_id,'key'=>$key,'api_key'=>$key];
    
    $params['form_params'] = $post_data;
 
    $response = $client->post($url, $params);
    
    $result = $response->getBody()->getContents();
    gg($result);
    $result = json_decode($result,true);
    gg($result);
   
    if(!$result || !$result['status'] || (is_array($result) && count($result) == 0)){
        $return = json_alert('PBX Aftersave error','error');
    }elseif($result['status'] != 'success'){
        $return =  json_alert($result['message'],'warning');
    }
  
    if(!empty($return)){
        return $return;
    }
}

function aftersave_extension_curl($request){
    return fusionpbx_edit_curl('http://156.0.96.60/app/extensions/extension_edit.php', $request->extension_uuid, $request->all(), true);
}

function aftersave_phone_numbers_curl($request){
    $domain_uuid = \DB::connection('pbx')->table('p_phone_numbers')->where('id',$request->id)->pluck('domain_uuid')->first();
    if($domain_uuid){
    $domain_name = \DB::connection('pbx')->table('v_domains')->where('domain_uuid', $domain_uuid)->pluck('domain_name')->first();
    if($domain_name){
    $pbx = new \FusionPBX;
    $pbx->portalCmd('delete_cache_item',"dialplan:".$domain_name);
    }
    }
   // return fusionpbx_edit_curl('http://156.0.96.60/app/phone_numbers/phone_number_edit.php', $request->id, $request->all());
    
}

function aftersave_voicemail_curl($request){
    return fusionpbx_edit_curl('http://156.0.96.60/app/voicemails/voicemail_edit.php', $request->voicemail_uuid, $request->all());
}

function aftersave_recordings_curl($request){
    
    try{
        if(!$request->use_text_to_speech){
            $recording = \DB::connection('pbx')->table('v_recordings')
            ->select('v_recordings.*','v_domains.domain_name','v_domains.account_id')
            ->join('v_domains','v_domains.domain_uuid','=','v_recordings.domain_uuid')
            ->where('recording_uuid',$request->recording_uuid)
            ->get()->first();
            if(!str_contains($recording->recording_filename,$recording->domain_name)){
                \DB::connection('pbx')->table('v_recordings')->where('recording_uuid',$request->recording_uuid)->update(['recording_filename'=>$recording->account_id.$recording->recording_filename]);
            }
            
            $upfile = public_path().'/uploads/pbx_erp/1991/'.$recording->recording_filename;
            $file = public_path().'/uploads/pbx_erp/1991/'.$recording->account_id.$recording->recording_filename;
            if(!file_exists($file) && file_exists($upfile)){
                File::move($upfile,$file);
            }
            
            $pbx_path = '/var/lib/freeswitch/recordings/'.$recording->domain_name.'/'.$recording->account_id.$recording->recording_filename;
           
            File::copy($file,$pbx_path);
        
            
        }else{
             return fusionpbx_edit_curl('http://156.0.96.60/app/recordings/recording_edit.php', $request->recording_uuid, $request->all());
        }
    }catch(\Throwable $ex){
        gg($ex->getMessage());
        return ['message'=>$ex->getMessage(),'status'=>'error'];
    }
}