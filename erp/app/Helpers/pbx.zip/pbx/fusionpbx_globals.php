<?php

function select_options_ringbacks($row){
    
   	$row = (object) $row;
    if (empty($row) || empty($row->domain_uuid)) {
        return [];
    }
	$ringtones = \DB::connection('pbx')->table('v_vars')->where('var_category','Ringtones')->orderBy('var_name')->pluck('var_name')->toArray();
	
	$tones = \DB::connection('pbx')->table('v_vars')->where('var_category','Ringtones')->orderBy('var_name')->pluck('var_name')->toArray();

    $domain_uuid = $row->domain_uuid;
    $domain_name = \DB::connection('pbx')->table('v_domains')->where('domain_uuid', $domain_uuid)->pluck('domain_name')->first();
    


    $routing = [];

    $recordings = \DB::connection('pbx')->table('v_recordings')->where('domain_uuid', $domain_uuid)->orderby('recording_filename')->get();
    foreach ($recordings as $ext) {
        $routing[$ext->recording_filename] = 'Recording '.$ext->recording_filename;
    }
    
    

    $mohs = \DB::connection('pbx')->table('v_music_on_hold')->where('domain_uuid', $domain_uuid)->orderby('music_on_hold_name')->get();
    $routing['local_stream://default'] = 'Music on hold '.'Default';
    foreach ($mohs as $moh) {
        $routing['local_stream://'.$domain_name.'/'.$moh->music_on_hold_name] = 'Music on hold '.$moh->music_on_hold_name;
    }
   
    
    foreach($ringtones as $ringtone){
        $routing['${'.$ringtone.'}'] = 'Ringtone '.$ringtone;
        
    }
   
    foreach($tones as $tone){
        $routing['${'.$tone.'}'] = 'Tone '.$tone;
        
    }
    return $routing;
				
}