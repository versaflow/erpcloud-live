-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: pbx.cloudtools.co.za    Database: call_records
-- ------------------------------------------------------
-- Server version	5.5.64-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `call_records_2020aug`
--

DROP TABLE IF EXISTS `call_records_2020aug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020aug` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL DEFAULT '',
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `currency` varchar(3) DEFAULT 'ZAR',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `prepaid_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `total_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway` varchar(50) DEFAULT NULL,
  `admin_rate` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost_usd` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_gp` decimal(10,5) NOT NULL,
  `admin_gpp` decimal(10,5) NOT NULL,
  `admin_bal` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `variables` longtext,
  `recording_file` text,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=894361 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2020dec`
--

DROP TABLE IF EXISTS `call_records_2020dec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020dec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2167151 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2020jul`
--

DROP TABLE IF EXISTS `call_records_2020jul`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020jul` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL DEFAULT '',
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `prepaid_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `total_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway` varchar(50) DEFAULT NULL,
  `admin_rate` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost_usd` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_bal` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `recording_file` text,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=221641 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2020jun`
--

DROP TABLE IF EXISTS `call_records_2020jun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020jun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL DEFAULT '',
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `prepaid_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `total_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway` varchar(50) DEFAULT NULL,
  `admin_rate` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost_usd` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_bal` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `recording_file` text,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24233 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2020nov`
--

DROP TABLE IF EXISTS `call_records_2020nov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020nov` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1576849 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2020oct`
--

DROP TABLE IF EXISTS `call_records_2020oct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020oct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1103680 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2020sep`
--

DROP TABLE IF EXISTS `call_records_2020sep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2020sep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=597150 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_2021jan`
--

DROP TABLE IF EXISTS `call_records_2021jan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_2021jan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2775417 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_inbound`
--

DROP TABLE IF EXISTS `call_records_inbound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_inbound` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `recording_file` text,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `mos` varchar(100) DEFAULT NULL,
  `variables` longtext,
  `partner_company` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=109099 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_inbound_variables`
--

DROP TABLE IF EXISTS `call_records_inbound_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_inbound_variables` (
  `call_records_inbound_id` int(11) DEFAULT NULL,
  `variables` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_lastmonth`
--

DROP TABLE IF EXISTS `call_records_lastmonth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_lastmonth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `summary_destination` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3737314 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_lastmonth_2`
--

DROP TABLE IF EXISTS `call_records_lastmonth_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_lastmonth_2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL DEFAULT '',
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `dest_summary` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `currency` varchar(3) DEFAULT 'ZAR',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `prepaid_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `total_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway` varchar(50) DEFAULT NULL,
  `admin_rate` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_cost_usd` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `admin_gp` decimal(10,5) NOT NULL,
  `admin_gpp` decimal(10,5) NOT NULL,
  `admin_bal` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `recording_file` text,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=818169 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_outbound`
--

DROP TABLE IF EXISTS `call_records_outbound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_outbound` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT 'wholesale',
  `domain_name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `media_time` datetime DEFAULT NULL,
  `answer_time` datetime DEFAULT NULL,
  `hangup_time` datetime DEFAULT NULL,
  `hangup_date` date DEFAULT NULL,
  `hangup_cause` varchar(255) DEFAULT NULL,
  `simbank_cause` varchar(255) DEFAULT NULL,
  `direction` varchar(50) DEFAULT NULL,
  `read_codec` varchar(50) DEFAULT NULL,
  `write_codec` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `pin_number` int(11) DEFAULT NULL,
  `ani` varchar(50) NOT NULL,
  `ani_source` varchar(255) NOT NULL,
  `caller_id_number` varchar(255) DEFAULT NULL,
  `callee_id_number` varchar(255) DEFAULT NULL,
  `is_ported` tinyint(1) DEFAULT '0',
  `destination` varchar(50) DEFAULT NULL,
  `summary_destination` varchar(50) DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `duration_mins` time DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `monthly_usage` decimal(10,3) NOT NULL DEFAULT '0.000',
  `unlimited_minutes` int(11) NOT NULL DEFAULT '0',
  `channels_used` int(11) NOT NULL DEFAULT '0',
  `partner_id` int(11) NOT NULL DEFAULT '0',
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `gateway_cost` decimal(10,3) DEFAULT NULL,
  `gateway_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `currency` varchar(3) DEFAULT 'ZAR',
  `admin_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `admin_gp` decimal(10,3) NOT NULL,
  `admin_gpp` int(11) NOT NULL,
  `partner_rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_profit` decimal(10,3) NOT NULL DEFAULT '0.000',
  `partner_balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `rate` decimal(10,3) NOT NULL DEFAULT '0.000',
  `cost` decimal(10,3) NOT NULL DEFAULT '0.000',
  `balance` decimal(10,3) NOT NULL DEFAULT '0.000',
  `recording_file` text,
  `mos` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `partner_company` varchar(255) DEFAULT NULL,
  `is_call_answered` int(1) NOT NULL DEFAULT '0',
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4334258 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_outbound_variables`
--

DROP TABLE IF EXISTS `call_records_outbound_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_outbound_variables` (
  `call_records_outbound_id` int(11) NOT NULL DEFAULT '0',
  `variables` longtext,
  `callflow` longtext,
  `app_log` longtext,
  PRIMARY KEY (`call_records_outbound_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_records_outbound_variables_lastmonth`
--

DROP TABLE IF EXISTS `call_records_outbound_variables_lastmonth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_records_outbound_variables_lastmonth` (
  `call_records_outbound_id` int(11) NOT NULL DEFAULT '0',
  `variables` longtext,
  PRIMARY KEY (`call_records_outbound_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers`
--

DROP TABLE IF EXISTS `p_ported_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `msisdn_to` varchar(20) NOT NULL DEFAULT '',
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'geographic',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8931760 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_crdb_6`
--

DROP TABLE IF EXISTS `p_ported_numbers_crdb_6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_crdb_6` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8952701 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_crdb_7`
--

DROP TABLE IF EXISTS `p_ported_numbers_crdb_7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_crdb_7` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8966202 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_crdb_8`
--

DROP TABLE IF EXISTS `p_ported_numbers_crdb_8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_crdb_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8949381 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_gnp_1`
--

DROP TABLE IF EXISTS `p_ported_numbers_gnp_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_gnp_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9079312 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_gnp_2`
--

DROP TABLE IF EXISTS `p_ported_numbers_gnp_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_gnp_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8946254 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_gnp_3`
--

DROP TABLE IF EXISTS `p_ported_numbers_gnp_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_gnp_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8944168 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_gnp_4`
--

DROP TABLE IF EXISTS `p_ported_numbers_gnp_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_gnp_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8937952 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_ported_numbers_gnp_5`
--

DROP TABLE IF EXISTS `p_ported_numbers_gnp_5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_ported_numbers_gnp_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `msisdn` varchar(20) NOT NULL,
  `rnoroute` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `network` varchar(255) NOT NULL DEFAULT '',
  `destination` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ported_unique` (`msisdn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8936267 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `p_routing_labels`
--

DROP TABLE IF EXISTS `p_routing_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_routing_labels` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(255) DEFAULT NULL,
  `routing_label` varchar(255) DEFAULT NULL,
  `gnp_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-16  5:58:06
