"use strict";

/**
 * this is experimental, and subject to change, use at your own risk!
 */
module.exports = require("../split");
